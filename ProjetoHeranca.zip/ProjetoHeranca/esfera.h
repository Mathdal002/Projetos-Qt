#ifndef ESFERA_H
#define ESFERA_H
#include<figurageometrica.h>
namespace mathd {

class Esfera:public FiguraGeometrica
{
public:
    Esfera();
};
}
#endif // ESFERA_H
