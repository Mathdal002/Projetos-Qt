#ifndef ESFERA_H
#define ESFERA_H


class Esfera
{
public:
    Esfera();
};

#endif // ESFERA_H
