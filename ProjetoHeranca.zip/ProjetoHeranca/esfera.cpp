#include "esfera.h"
namespace mathd {


Esfera::Esfera()
{

}
}
