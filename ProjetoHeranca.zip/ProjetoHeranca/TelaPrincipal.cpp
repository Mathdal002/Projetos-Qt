#include "TelaPrincipal.h"
#include "ui_TelaPrincipal.h"

TelaPrincipal::TelaPrincipal(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

TelaPrincipal::~TelaPrincipal()
{
    delete ui;
}


void TelaPrincipal::on_pushButton_clicked(){
    try {
        mathd::FiguraGeometrica teste(-5);
        QString saida = teste.toString();
        saida += "\n"+ teste.obterTipoFigura();
        ui->textEdit->setText(saida);
    } catch (QString &erro) {
        QMessageBox::information(this, "Erro Do Sistema", erro);
    }
}

